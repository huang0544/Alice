CREATE TRIGGER updateDatingSponsorName
  AFTER UPDATE
  ON Users
  FOR EACH ROW
  BEGIN
IF(old.name != new.name) THEN 
IF(SELECT DISTINCT datingSponsorEmail FROM Dating WHERE datingSponsorEmail = old.email) THEN
UPDATE Dating SET datingSponsorName = new.name WHERE datingSponsorEmail = old.email;
END IF;
END IF;
END;

